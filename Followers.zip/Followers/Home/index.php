<?php
session_start();
error_reporting(0);
if (!$_SESSION['login'] == 'true') header('Location: ../auth/login');


function get_avatar(){
    global $ipaddress;
    $username = $_SESSION['username'];
    
    $login  = curl_init();
    $headers = array(
        "Cookie: _ga=GA1.2.222848298.1647350236; __atuvc=1%7C11%2C0%7C12%2C0%7C13%2C2%7C14; _cpguid=1uenjkbhd; __cf_bm=7HAg6kC81WxLn36pciRkoV9m_VnTA14am4NS3CfSIaM-1649096542-0-AZzdhynUHxmQ/BDbov5hoMgpK7t1h+OvpSv3Tq+IG4N6UN7yOnJXHe68QR8ESMV7awrU/0I4cV0iwUq4QNN/FWZgKpQdWpgslFwExONA3AuYAVHLuQ8UKT9CFto6XrvH3w==; _gid=GA1.2.1010129432.1649096531; _gat_gtag_UA_132860463_1=1; __atuvs=624b375c1a531f2c000",
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0",
        "X-Forwarded-For: $ipaddress"
    );
    curl_setopt($login,CURLOPT_URL,"https://privatephotoviewer.com/usr/$username");
    curl_setopt($login , CURLOPT_FOLLOWLOCATION , true);
    curl_setopt($login , CURLOPT_POST , 0);
    curl_setopt($login , CURLOPT_RETURNTRANSFER , true);
    curl_setopt($login,CURLOPT_HTTPHEADER,$headers);
    $result = curl_exec($login);



    $One = strstr($result,'<img src=');
    $Tow = strstr($One,'style',true);
    $thre = str_replace('<img src=','',$Tow);
    return $thre;
}


function update_cookies(){
    global $ipaddress;
    $v1 = $_SESSION['88ae92e37168eafe33e65e5fc815ee79'];
    $login  = curl_init();
    $headers = array(
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0',
        "Cookie: 88ae92e37168eafe33e65e5fc815ee79=$v1;",
        "X-Forwarded-For: $ipaddress"
    );
    curl_setopt($login,CURLOPT_URL,"https://takipcikutusu.com/tools");
    curl_setopt($login , CURLOPT_FOLLOWLOCATION , true);
    curl_setopt($login , CURLOPT_POST , 0);
    curl_setopt($login,CURLOPT_HEADER,1);
    curl_setopt($login , CURLOPT_RETURNTRANSFER , true);
    curl_setopt($login,CURLOPT_HTTPHEADER,$headers);

    $result = curl_exec($login);
    preg_match_all("/88ae92e37168eafe33e65e5fc815ee79=([^;]+)/i",$result,$e88);

    if ($e88[1][0]){
        $_SESSION['88ae92e37168eafe33e65e5fc815ee79'] = $e88[1][0];
        $_SESSION['update'] = 'true';
    } else {
        header('Location: ../auth/logout.php');
    }
}

if ($_SESSION['update'] != 'true'){
    Update_cookies();
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>GIVT - Home</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/4805b8acb8.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
<link rel="stylesheet" href="https://allyoucan.cloud/cdn/icofont/1.0.1/icofont.css" integrity="sha384-jbCTJB16Q17718YM9U22iJkhuGbS0Gd2LjaWb4YJEZToOPmnKDjySVa323U+W7Fv" crossorigin="anonymous">

<div class="container">
    <div class="row">
        <div class="col-md-3">
            <div class="osahan-account-page-left shadow-sm bg-white h-100">
                <div class="border-bottom p-4">
                    <div class="osahan-user text-center">
                        <div class="osahan-user-media">
                            <img class="mb-3 rounded-pill shadow-sm mt-1" src="<?php echo get_avatar();?>">
                            <div class="osahan-user-media-body">
                                <h6 class="mb-2">Welcome @<?php echo $_SESSION["username"];?></h6>
                                <p class="mb-1"></p>
                                
                                <p class="mb-0 text-black font-weight-bold"><a class="text-primary mr-3"  href="../auth/logout.php">تسجيل الخروج</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <ul class="nav nav-tabs flex-column border-0 pt-4 pl-4 pb-4" id="myTab" role="tablist">
                    
                    <li class="nav-item">
                        <p>You Can Check The Main website -> <a href="https://givt.pw">GIVT</a></p>
                    </li>
                    <li class="nav-item">
                        <p>My Telegram <a href="https://t.me/givtt">@givtt</a></p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-md-9">
            <div class="alert alert-warning">
                <strong><i class="fa-solid fa-triangle-exclamation"></i> Warning ! :</strong> استخدم حساب وهمي وارسل المتابعين لحسابك الاساسي
            </div>

            <div class="alert alert-danger">
                <strong>Warning ! </strong> قم بتغير كلمة مرور الحساب الوهمي .. قد يتم استخدامه
            </div>

            <div class="alert alert-info">
                <strong><i class="fa-solid fa-info"></i>: </strong>   عند وضع افتار للحساب يصل عدد متابعين اكثر  
            </div>
            
            <div class="osahan-account-page-right shadow-sm bg-white p-4 h-100">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane  fade  active show" id="orders" role="tabpanel" aria-labelledby="orders-tab">
                        <h4 class="font-weight-bold mt-0 mb-4">خدمات الموقع</h4>
                        <div class='bg-white card mb-4 order-list shadow-sm'>
                            <div class='gold-members p-4'>
                                <a href='#'>
                                </a>
                                <div class='media'>
                                    <a href='#'>
                                        <img class='mr-4' src='https://www.pngplay.com/wp-content/uploads/12/Instagram-Logo-Transparent-Free-PNG.png' alt=''> 
                                    </a>
                                    <div class='media-body'>
                                        
                                        <h6 class='mb-2'>
                                            <a href='#'></a>
                                            <p>رشق متابعين انستقرام</p>
                                        </h6>
                                        
                                        <p class='text-gray mb-3'><i class='icofont-list'></i>ترشق للحساب اللي تبيه</p>
                                        <p class='text-dark'>خدمة مجانية</p>
                                        <hr>
                                        <div class='float-right'>
                                            
                                        </div>
                                        <p class='mb-0 text-black text-primary pt-2'><span class='text-black font-weight-bold'><a class="btn btn-primary" href="../send/followers.php" role="button"><i class="fa-solid fa-user-plus"></i>رشق متابعين </a></span></p>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class='bg-white card mb-4 order-list shadow-sm'>
                            <div class='gold-members p-4'>
                                <a href='#'>
                                </a>
                                <div class='media'>
                                    <a href='#'>
                                        <img class='mr-4' src='https://www.pngplay.com/wp-content/uploads/12/Instagram-Logo-Transparent-Free-PNG.png' alt=''> 
                                    </a>
                                    <div class='media-body'>
                                        <h6 class='mb-2'>
                                            <a href='#'></a>
                                            <p>رشق مشاهدات ستوري انستقرام</p>
                                        </h6>
                                        
                                        <p class='text-gray mb-3'><i class='icofont-list'></i>ترشق الستوري اللي تبيه</p>
                                        <p class='text-dark'>خدمة مجانية</p>
                                        <hr>
                                        <div class='float-right'>
                                            
                                        </div>
                                        <p class='mb-0 text-black text-primary pt-2'><span class='text-black font-weight-bold'><a class="btn btn-primary" href="../send/views.php" role="button"><i class="fa-solid fa-eye"></i>رشق مشاهدات </a></span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style type="text/css">
body{
    margin-top:20px;
    background:#eee;
}
/* My Account */
.payments-item img.mr-3 {
    width: 47px;
}
.order-list .btn {
    border-radius: 2px;
    min-width: 121px;
    font-size: 13px;
    padding: 7px 0 7px 0;
}
.osahan-account-page-left .nav-link {
    padding: 18px 20px;
    border: none;
    font-weight: 600;
    color: #535665;
}
.osahan-account-page-left .nav-link i {
    width: 28px;
    height: 28px;
    background: #535665;
    display: inline-block;
    text-align: center;
    line-height: 29px;
    font-size: 15px;
    border-radius: 50px;
    margin: 0 7px 0 0px;
    color: #fff;
}
.osahan-account-page-left .nav-link.active {
    background: #f3f7f8;
    color: #282c3f !important;
}
.osahan-account-page-left .nav-link.active i {
    background: #282c3f !important;
}
.osahan-user-media img {
    width: 90px;
}
.card offer-card h5.card-title {
    border: 2px dotted #000;
}
.card.offer-card h5 {
    border: 1px dotted #daceb7;
    display: inline-table;
    color: #17a2b8;
    margin: 0 0 19px 0;
    font-size: 15px;
    padding: 6px 10px 6px 6px;
    border-radius: 2px;
    background: #fffae6;
    position: relative;
}
.card.offer-card h5 img {
    height: 22px;
    object-fit: cover;
    width: 22px;
    margin: 0 8px 0 0;
    border-radius: 2px;
}
.card.offer-card h5:after {
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-bottom: 4px solid #daceb7;
    content: "";
    left: 30px;
    position: absolute;
    bottom: 0;
}
.card.offer-card h5:before {
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 4px solid #daceb7;
    content: "";
    left: 30px;
    position: absolute;
    top: 0;
}
.payments-item .media {
    align-items: center;
}
.payments-item .media img {
    margin: 0 40px 0 11px !important;
}
.reviews-members .media .mr-3 {
    width: 56px;
    height: 56px;
    object-fit: cover;
}
.order-list img.mr-4 {
    width: 70px;
    height: 70px;
    object-fit: cover;
    box-shadow: 0 .125rem .25rem rgba(0, 0, 0, .075)!important;
    border-radius: 2px;
}
.osahan-cart-item p.text-gray.float-right {
    margin: 3px 0 0 0;
    font-size: 12px;
}
.osahan-cart-item .food-item {
    vertical-align: bottom;
}

.h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6 {
    color: #000000;
}

.shadow-sm {
    box-shadow: 0 .125rem .25rem rgba(0,0,0,.075)!important;
}

.rounded-pill {
    border-radius: 50rem!important;
}
a:hover{
    text-decoration:none;
}
</style>

<script type="text/javascript">

</script>
</body>
</html>