<?php
session_start();
error_reporting(0);
if (!$_SESSION['login'] == 'true') header('Location: ../auth/login');
if (isset($_SERVER['HTTP_CLIENT_IP']))
$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
else if(isset($_SERVER['HTTP_X_FORWARDED']))
$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
$ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
else if(isset($_SERVER['HTTP_FORWARDED']))
$ipaddress = $_SERVER['HTTP_FORWARDED'];
else if(isset($_SERVER['REMOTE_ADDR']))
$ipaddress = $_SERVER['REMOTE_ADDR'];
else die('use vpn');



$token = $_SESSION['88ae92e37168eafe33e65e5fc815ee79'];
function get_point(){
    global $ipaddress;

    $token = $_SESSION['88ae92e37168eafe33e65e5fc815ee79'];
    
    $login  = curl_init();
    $headers = array(
        "Cookie: 88ae92e37168eafe33e65e5fc815ee79=$token",
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0',
        "X-Forwarded-For: $ipaddress"
    );

    curl_setopt($login,CURLOPT_URL,"https://takipcikutusu.com/tools/");
    curl_setopt($login , CURLOPT_FOLLOWLOCATION , true);
    curl_setopt($login , CURLOPT_POST , 0);
    curl_setopt($login,CURLOPT_HTTPHEADER,$headers);
    curl_setopt($login , CURLOPT_RETURNTRANSFER , true);

    $result = curl_exec($login);
    

    if (strpos('class="fa fa-sign-in">', $result)){
        header('Location: ../auth/logout.php');
    } else {
        $One = strstr($result,'id="storyKrediCount">');
        $tow = strstr($One,'<',true);
        $End = str_replace('id="storyKrediCount">','',$tow);
        return htmlspecialchars($End);
    }
}
$point = get_point();

function get_username_id($target){
    global $ipaddress;
    $token = $_SESSION['88ae92e37168eafe33e65e5fc815ee79'];
    $login  = curl_init();
    $data = array(
        "username" => $target
    );
    $headers = array(
        "Cookie: 88ae92e37168eafe33e65e5fc815ee79=$token",
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0',
        "X-Forwarded-For: $ipaddress"
    );
    curl_setopt($login,CURLOPT_URL,"https://takipcikutusu.com/tools/send-follower?formType=findUserID");
    curl_setopt($login , CURLOPT_FOLLOWLOCATION , true);
    curl_setopt($login , CURLOPT_POST , true);
    curl_setopt($login,CURLOPT_HEADER,1);
    curl_setopt($login , CURLOPT_POSTFIELDS , $data);
    curl_setopt($login,CURLOPT_HTTPHEADER,$headers);
    curl_setopt($login , CURLOPT_RETURNTRANSFER , true);
    $result = curl_exec($login);
    
    $One = strstr($result,'name="userID" value="');
    $Tow = strstr($One, '">', true);
    $Three = str_replace('name="userID" value="', '', $Tow);
    if ($Three){
        return $Three;
    } else {
        return 'error';
        
    }


}

if (isset($_POST['username'])){
    $target = $_POST['username'];
    if ($target[0] == "@"){
        $message = "Error";
    } else {
        if (get_username_id($target) == "error"){
            $message = '
            <div class="alert alert-danger">
                <strong>Error !</strong> The Username is Private Or Not Found 
            </div>
            ';
        } else {
            $username_id = get_username_id($target);
            $login = curl_init();
            $headers = array(
                "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0",
                "Cookie: 88ae92e37168eafe33e65e5fc815ee79=$token",
                "X-Forwarded-For: $ipaddress"

            );
            $data = array(
                "adet" => "1000",
                "userID" => $username_id,
                "userName" => $target
            );
            curl_setopt($login,CURLOPT_URL,"https://takipcikutusu.com/tools/story-view/$username_id?formType=send");
            curl_setopt($login , CURLOPT_FOLLOWLOCATION , true);
            curl_setopt($login , CURLOPT_POST , true);
            curl_setopt($login , CURLOPT_POSTFIELDS , $data);
            curl_setopt($login,CURLOPT_HTTPHEADER,$headers);
            curl_setopt($login , CURLOPT_RETURNTRANSFER , true);
            $result = curl_exec($login);
            if (strpos($result,'success')){
                $message = '
                <div class="alert alert-success">
                    <strong>Success!</strong> Done Send 100 Views
                </div>
                ';
            } elseif (strpos($result,'nocreditleft')) {
                $message = '
                <div class="alert alert-danger">
                    <strong>Error !</strong> Your point Is 0
                </div>
                ';
            } elseif (strpos($result,'nolimitdefined')){
                $message = '
                <div class="alert alert-danger">
                    <strong>Error !</strong> No Story Found 
                </div>
                ';
            } 
            else {
                $message = '
                <div class="alert alert-danger">
                    <strong>Error !</strong> Something wrong
                </div>
                ';
            }
        }
    }
}



?>
<html lang="ar">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GIVT - Send Views</title>    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600;700&amp;display=swap">
    <link rel="stylesheet" href="all.css">
    <script src="https://kit.fontawesome.com/4805b8acb8.js" crossorigin="anonymous"></script>
</head>



<body style="background-color: #eeeeee;" data-layout="horizontal" data-topbar="dark" style="padding: 0px;">
<div id="layout-wrapper" style="height: auto !important;">

    <div class="main-content" style="height: auto !important;">
        <div class="page-content" style="height: auto !important;">
            <div class="container-fluid" style="height: auto !important;">        

<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card hidden" id="field_cd"></div>
        <div id="field_form">
            <div class="card border border-success">
                <div class="card-body text-center" style="background-color: #ffffff;">
                    <h4 style="color:black" class="card-text">You Can Send : <span class="badge bg-success"><?php echo $point?> Views And More !</span></h4>
                    <h4 style="color:black" class="card-text">Your Point : <span class="badge bg-success"><?php echo $point;?></span></h4>
                    <span style="color:black" class="mt-3">Change Your Account To get Point</span>
                </div>
            </div>
            <div class="alert alert-warning">
                <strong>Warning! :</strong> يتم تجديد النقاط كل 24 ساعة
            </div>
            <div style="background-color: #ffffff;" class="card">
                <div class="card-header bg-success bg-gradient text-white"><i class="fa-solid fa-users"></i> Send Instagram Story Views</div>
                <div id="field_feed">
                    <form action="views.php" method="POST" autocomplete="off">
                        <div class="card-body">
                            <label style="color: black;" class="form-label" for="link">Username :</label>
                            <input style="background-color: #f7f7f7; color:black" type="text" class="form-control" name="username" placeholder="Username without @" required="">
                        </div>
                        <div class="card-footer">
                            <button class="btn btn-success bg-gradient w-sm waves-effect waves-light">Send</button>
                            <a href="../Home/index.php" class="btn btn-success bg-gradient w-sm waves-effect waves-light">Back To Home Page</a>
                        </div>
                    </form>
                </div>
                
            </div>
            <?php

            if ($message){
                echo $message;
            }

            ?>
        </div>
    </div>
</div>
</div>
</div>
</div>

</div></body></html>